angular.module('rezumeFilters', []).filter('roubles', function(input){
	return function(input) {
		var r = String(input).replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 ') + ' руб.';
		return r;
	};
});
